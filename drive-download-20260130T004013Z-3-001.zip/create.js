let form = document.querySelector("#settings-form");
let movieInput = document.querySelector("#movieInput");
let genreInput = document.querySelector("#genreInput");
let ratingInput = document.querySelector("#ratingInput");
let yearInput = document.querySelector("#yearInput");
let message = document.querySelector("#MessageText");

function getNextId() {
    if (!data || data.length === 0) return 1;
    return data.length + 1;
}


function submitData(newObj) {
    if (!Array.isArray(data)) data = [];
    data.push(newObj);
    console.log("Data submitted:", newObj);

    if (grid) {
        let card = document.createElement("div");
        card.classList.add("card");
        card.innerHTML = 
            "<div class='song-title'>" + (newObj.title || "") + "</div>" +
            "<span>Genre: " + (newObj.genre || "") + "<br>Notes: " + (newObj.notes || "") + "</span>";
        grid.appendChild(card);
    }
}

function SendMessage(movieName) {
    message.innerHTML = "New Movie added: " + movieName;
}


form.addEventListener("submit", function(e){
    e.preventDefault();
    let movie = movieInput.value 
    let genre = genreInput.value 
    let rating = ratingInput.value 
    let year = yearInput.value 

    let newObj = {
        "id": getNextId(),
        "Movie": movie,
        "Genre": genre,
        "Rating": rating,
        "Year": year 
    };
    submitData(newObj);
    form.reset();
    SendMessage(movie);
})